from flask import Flask, jsonify, request, render_template
from flask_cors import CORS, cross_origin
import sqlite3 as sql
from functions import * 

app = Flask(__name__, template_folder="front-end")
app.config['JSON_AS_ASCII'] = False



#CORS(app)

def executeDB(command):
	db = sql.connect("dados.db")
	cursor = db.cursor()
	cursor.execute(command)
	db.commit()
	db.close()

db = sql.connect("dados.db")
cursor = db.cursor()
r = cursor.execute("SELECT comments FROM posts WHERE title = 'O que é JavaScript'")
fet = r.fetchall()
db.close()

#print(fet)

@app.route("/")
def homepage():
	return render_template('landing.html')

@app.route("/api/v1/create/user", methods=["POST"])
def CriarUser():
	data = request.get_json()
	#print(data)

	# Verificando os ID's
	db = sql.connect("dados.db")
	cursor = db.cursor()
	r = cursor.execute("SELECT id FROM users")
	fet = r.fetchall()
	db.close()

	idGerado = geradorDeID()

	# Verificar se o ID já existe no banco de dados
	if idGerado in fet:
		return jsonify({
			"message": "Error"
		})

	db = sql.connect("dados.db")
	cursor = db.cursor()
	r = cursor.execute("SELECT username FROM users")
	fet = r.fetchall()
	db.close()

	if data['username'] in fet:
		return jsonify({
			"message": "Error"
		})


	db = sql.connect("dados.db")
	cursor = db.cursor()
	cursor.execute("INSERT INTO users (username, password, id) VALUES (?,?,?)", (data["username"], data["password"], idGerado))
	db.commit()
	db.close()

	return jsonify({
		"message": "OK",
		"id": idGerado
	})

@app.route("/api/v1/login/user", methods=["GET"])
def loginUser():
	username = request.args.get("username")
	senha = request.args.get("password")

	# Se o usuário existe
	db = sql.connect("dados.db")
	cursor = db.cursor()
	r = cursor.execute("SELECT * FROM users WHERE username = ?", (username,))
	fetc = r.fetchone()
	db.close()

	if fetc == None:
		return jsonify({
			"message": "User Not Exist"
			})
	else:
		# Pegar senha do usuário
		db = sql.connect("dados.db")
		cursor = db.cursor()
		r = cursor.execute("SELECT password, id FROM users WHERE username = ?", (username,))
		fetc = r.fetchall()
		db.close()
		# print(fetc[0][0])
		if senha == fetc[0][0]:
			return jsonify({
				"message": "OK",
				"id": fetc[0][1]
				})
		else:
			return jsonify({
				"message": "Incorrect Password",
				"count": random.randint(5, 15)
				})

@app.route("/api/v1/create/post", methods=["POST", "GET"])
def criarPost():
	data = request.get_json()
	title = data["title"]
	autor = data["author"]
	conteudo = data["conteudo"]

	# Verificar se o Artigo já existe
	db = sql.connect("dados.db")
	cursor = db.cursor()
	r = cursor.execute("SELECT * FROM posts WHERE title = ?", (title,))
	fetc = r.fetchone()
	db.close()

	if fetc != None:
		return jsonify({
			"message": "Artigo Existe"
		})

	else:
		dados = {
			"title": title,
			"author": autor,
			"conteudo": conteudo
		}

		# print(dados)

		
		db = sql.connect("dados.db")
		cur = db.cursor()
		cur.execute("INSERT INTO posts (title, conteudo, author, comments, likes) VALUES (?,?,?,?,?)", (dados['title'], dados['conteudo'], dados['author'], "guxtavodev:otimoo", 0))
		cur.execute("INSERT INTO likes (author, post) VALUES (?,?)", ('guxtavodev', dados['title']))
		db.commit()
		db.close()

		return jsonify({
			"message": "OK"
		})

@app.route("/api/v1/get/posts", methods=["GET"])
def getPosts():
	return jsonify({
		"posts": ArtigosHome()
	})

@app.route("/home")
def pageinit():
	return render_template('index.html')

@app.route("/entrar")
def entrarPage():
	return render_template('login.html')

@app.route("/cadastro")
def cadastrarPage():
	return render_template('cadastro.html')

@app.route('/post/<title>')
def post(title):
	title = title.replace("-", " ")
	artigo = getArtigo(title)

	return render_template("post.html", title=artigo["title"], conteudo=artigo['conteudo'], author=f"{artigo['author']}")

@app.route("/post/comments", methods=["GET"])
def getComments():
	title = request.args.get('post')
	title = title.replace("-", " ")
	return jsonify({
		"comments": Comentarios(title)
	})
 
@app.route("/api/v1/create/comment", methods=["POST"])
def addComment():
	data = request.get_json()
	# print(data)
	db = sql.connect('dados.db')
	cur = db.cursor()
	r = cur.execute("""
		SELECT comments FROM posts WHERE title = ?
	""", (data["post"],))
	fet = r.fetchone()
	db.close()

	newComentario = f'{fet[0]}&{data["author"]}:{data["content"]}'
	db = sql.connect('dados.db')
	cur = db.cursor()
	cur.execute("""
		UPDATE posts
		SET comments = ?
		WHERE title = ?
""", (newComentario, data["post"]))
	db.commit()
	db.close()

	return jsonify({
		"message": "Comentário Adicionado!"
		})

@app.route('/api/v1/add/like', methods=["POST"])
def addLike():
	data = request.get_json()


	db = sql.connect('dados.db')
	cur = db.cursor()
	cur.execute("""
		INSERT INTO likes (author, post) VALUES (?,?)
""", (data["author"], data["post"]))
	db.commit()
	db.close()

	usernameAuthor = getArtigo(data['post'])["author"]

	db = sql.connect('dados.db')
	cur = db.cursor()
	r = cur.execute("""
		SELECT likes FROM users WHERE username = ?
""", (usernameAuthor,))
	res = r.fetchone()[0]
	db.commit()
	db.close()
	# print(res)

	print(res)
	if res == None:
		res = 0 
	else:
		pass

	db = sql.connect('dados.db')
	cur = db.cursor()
	r = cur.execute("""
			UPDATE users 
			SET likes = ?
			WHERE username = ?
	""", (str(int(res+1)), usernameAuthor))
	db.commit()
	db.close()

	return jsonify({
		"message": "Like!"
		})

@app.route("/api/v1/get/likes", methods=["GET"])
def getLikes():
	post = request.args.get('post')
	post = post.replace("-", " ")
	db = sql.connect('dados.db')
	cur = db.cursor()
	r = cur.execute("""
		SELECT author FROM likes WHERE post = ?
	""", (post, ))
	fet = r.fetchall()
	db.close()
	print(len(fet))
	return jsonify({
		"likes": len(fet)
		})

@app.route("/api/v1/user", methods=["GET"])
def pegarUsuario():
	nome = request.args.get("username")
	try:
		return jsonify({
			"message": getUser(nome)
		})
	except:
		return jsonify({
			"message": "Error"
		})

@app.route('/api/v1/edit/user', methods=["POST"])
def editUser():
	data = request.get_json()

	db = sql.connect("dados.db")
	cursor = db.cursor()
	r = cursor.execute("SELECT username FROM users")
	fet = r.fetchall()	
	db.close()

	if data['username'] in fet:
		return jsonify({
			"message": "Error"
		})

	db = sql.connect('dados.db')
	cur = db.cursor()
	cur.execute(f"""
		UPDATE users
		SET username = ?,
			email = ?,
			telephone = ?,
			password = ?,
			links = ?,
			bio = ?

		WHERE id = ?
		""", (data['username'] or "", 
			data['email'] or "",
			data['telephone'] or "",
			data['password'] or "",
			data['link'] or "",
			data['bio'] or "",
			data['usernameLast']
			)
		)

	db.commit()
	db.close()
	return jsonify({
		"message": "OK"
		})

@app.route('/perfil/<username>')
def perfil(username):
	user = getUser(username)
	db = sql.connect('dados.db')
	cur = db.cursor()
	r = cur.execute("SELECT * FROM posts WHERE author = ?", (user['username'],))
	rer = r.fetchall()
	db.close()
	postsUser = []
	for post in rer:
		posts = {}
		print(post)
		postsUser.append(f"""
				<div class="post">
					<a href="/post/{post[0].replace(" ", "-")}"><p><strong>{post[0]}</strong></p></a>
					<p>{post[1]}</p>
				</div>
			""")

	pe = "".join(map(str, postsUser))
	# print(pe)
	return render_template('profile.html', username=user['username'], bio=user['bio'], posts=pe)

@app.route("/settings")
def configuracao():
	return render_template("config.html")

@app.route('/api/v1/wiki/<username>', methods=["GET"])
def listarWikis(username):
	# Pegar os wikis que tem como author o Guxtavo
	db = sql.connect('dados.db')
	cur = db.cursor()
	r = cur.execute('SELECT * FROM wikis WHERE author = ?', (username,))
	result = r.fetchall()
	db.close()

	# Registrar as wikis numa lista
	wikis = []

	for wiki in result:
		wikis.append({
			"title": wiki[0],
			"content": wiki[1],
			"author": wiki[2]
		})

	if len(wikis) == 0:
		return jsonify({
			"message": "Nenhum wiki"
		})

	return jsonify({
		"message": wikis
		})

@app.route('/wiki/<username>')
def wikiExibir(username):
	return render_template('wikis.html', user=username)


#executeDB('CREATE TABLE wikis ( title TEXT, content TEXT, author TEXT )')

@app.route('/api/v1/create/wiki', methods=['POST'])
def newWiki():
	data = request.get_json()
	try:
		db = sql.connect('dados.db')
		cur = db.cursor()
		cur.execute("INSERT INTO wikis (title, content, author) VALUES (?,?,?)", (
				data["title"],
				data['content'],
				data['author']
			))
		db.commit()
		db.close()
		return jsonify({
			"message": "OK"
		})
	except:
		return jsonify({
			"message": "Error"
			})

@app.route("/api/v1/edit/post", methods=["POST"])
def editPost():
	json = request.get_json()

	try:
		artigoData = getArtigo(json["title"])
		# Salvando as alterações no banco de dados
		db = sql.connect("dados.db")
		cursor = db.cursor()
		cursor.execute("UPDATE posts SET title = ?, conteudo = ? WHERE title = ?", (json["post"], json["body"], json["title"]))
		db.commit()
		db.close()
		return jsonify({
			"message": "success"
			})
	except Exception as e:
		print(e)
		return jsonify({
			"message": "Error"
			})

@app.route("/api/v1/delete/post", methods=["POST"])
def deletePost():
	json = request.get_json()
	try:
		# Excluindo o artigo no banco de dados
		db = sql.connect("dados.db")
		cursor = db.cursor()
		cursor.execute("DELETE FROM posts WHERE title = ?", (json["post"],))
		db.commit()
		db.close()
		return jsonify({
			"message": "success"
			})
	except Exception as e:
		raise e

@app.route("/api/v1/delete/user", methods=["POST"])
def deleteUser():
	json = request.get_json()
	try:
		db = sql.connect("dados.db")
		cursor = db.cursor()
		cursor.execute("DELETE FROM users WHERE id = ?", (json["user"],))
		db.commit()
		db.close()
		return jsonify({
			"message": "success"
		})
	except Exception as e:
		raise e

if __name__ == "__main__":
	app.run(host='0.0.0.0', port=2019)