async function Cadastrar() {
	const newUser = {
		"username": document.getElementById("username").value,
		"password": document.getElementById("pass").value
	}

	if(newUser.username.includes("#") || newUser.username.includes("=") || newUser.username.includes("&")) {
		return Swal.fire("Seu nome de usuário não pode conter: #, = ou &")
	} 

	if(newUser.username.includes(" ")) {
		return Swal.fire("Seu nome de usuário não pode conter espaços")
	}
	
	await axios.post("/api/v1/create/user", {
		"username": newUser.username,
		"password": newUser.password
	}).then((res) => {
		console.log(res.data)
		if(res.data["message"] === "Error") {
			return Swal.fire({
				icon: 'error',
				title: 'Ocorreu um erro interno',
				text: "Tente novamente"
			})
		}

		if(res.data["message"] === "OK") {
			Swal.fire({
			  position: 'top-end',
			  icon: 'success',
			  title: 'Inscrição feita com sucesso!',
			  showConfirmButton: false,
			  timer: 1500
			})
			localStorage.setItem('id', res.data["id"])
			localStorage.setItem('username', newUser.username)
			window.location.href="/home"
		}
	})
}

// Swal.fire('Seja bem vindo')

async function Login() {
	const dados = {
		"username": document.getElementById("username").value,
		"password": document.getElementById("pass").value
	}

	await axios.get(`/api/v1/login/user?username=${dados.username}&password=${dados.password}`).then((res) => {
		console.log(res.data)
		var result = res.data
		var tempo = `${res.data['count']}000` || ""

		if(result["message"] === "User Not Exist") {
			return Swal.fire({
				icon: "error",
				title: "Usuário não existe"
			})
		}

		if(result["message"] === "Incorrect Password") {
			var button = document.querySelector('button')
			
			return Swal.fire({
				icon: "error",
				title: "Senha Incorreta!"
			})
		}
		localStorage.setItem('id', result["id"])
		localStorage.setItem('username', document.getElementById('username').value)
		window.location.href = "/home"
	})
}

var converter = new showdown.Converter(),
    text      = '## hello, **markdown**',
    html      = converter.makeHtml(text);

console.log(html)
