$(document).ready(function() {
	
	let username = document.querySelector('span').textContent
	axios.get(`http://127.0.0.1:2019/api/v1/wiki/${username}`).then((res) => {
		var data = res.data['message']
		if(data === 'Nenhum wiki') {
			Swal.fire({
				icon: 'warning',
				title: 'O usuário não tem nenhum wiki publicado',
				text: 'Retornando a página do usuário...'
			})
			window.location.href = `http://127.0.0.1:2019/perfil/${username}`
		} else {
			data.forEach(function(wiki) {
				let divWikis = document.querySelector('.list-wikis')
				divWikis.innerHTML += `
					<a key='${wiki['title']}' href="#">${wiki['title']}</a>
				`

				
			})
			// Pega os keys dos elemento
			$('.list-wikis').find('a').click(function() {
				var title = $(this).attr('key')
				data.forEach(function(wiki) {
					if(title === wiki['title']) {
						return Swal.fire({
							title: wiki['title'],
							text: wiki['content']
						})
					}
				})
			})

		}
	})
	
if(localStorage.getItem("mode") === "dark") {
    document.querySelector('body').setAttribute("class", "dark-mode")
}

})