function Preview() {
	var conteudo = document.getElementById("conteudo").value

	var converter = new showdown.Converter(),
    text      = conteudo,
    html      = converter.makeHtml(text);

    Swal.fire({
    	title: "Preview",
    	html: html
    })
}

async function EnviarPost() {
    const bodyPost = {
        "title": document.getElementById('post-title').value,
        "conteudo": document.getElementById('conteudo').value,
        "author": localStorage.getItem('username')
    }



    let response = await axios.post('/api/v1/create/post', {
        "title": bodyPost.title,
        "conteudo": bodyPost.conteudo,
        "author": bodyPost.author,
    }).then((res) => {
        console.log(res.data)
        Swal.fire({
                  position: 'top-end',
                  icon: 'success',
                  title: 'Artigo criado com sucesso!',
                  showConfirmButton: false,
                  timer: 1500
        })
    })
}

axios.get('/api/v1/get/posts').then((res) => {
    var data = res.data
    const listaPosts = data['posts']
    console.log(listaPosts)

    listaPosts.forEach(function(post, index) {
        console.log(post)
        var divPosts = document.querySelector('.list-posts')

        

        divPosts.innerHTML += `
        
            <div class="post" id="87428372">
            <div class="header-post">
                <a href='/post/${post["title"].replace(" ", "-")}''>
                <p class="title-post-a">
                    <strong>${post['title']}</strong>
                </p>
                </a>
                <a href='/perfil/${post.author}'>
                <p class="author-post-a">
                    ${post['author']}
                </p>
                </a>
            </div>
            <div class="previa-post">
                ${post['conteudo'].substr(0, 100)}...
            </div>
            <div class="comentar">
                <input type="text" key='${post["title"]}' placeholder="Digite seu comentário" id="comment-text" key="e89wewew">
            </div>
        </div>
    
        `
    })
})

function createWiki() {
    Swal.fire({
        title: 'Criação de Wiki',
        html: `
            <div class='form-g'>
                <label>Título</label>
                <input type='text' id='titulo-wiki'>
            </div>
            <div class='form-g'>
                <label>Conteúdo</label>
                <textarea id='conteudo-wiki'></textarea>
            </div>
        `,
        showDenyButton: true,
        showCancelButton: true,
        confirmButtonText: 'Criar',
        denyButtonText: `Cancelar`
    }).then((result) => {
        if(result.isConfirmed) {
        axios.post(`/api/v1/create/wiki`, {
            "title": $('#titulo-wiki').val(),
            "content": $('#conteudo-wiki').val(),
            "author": localStorage.getItem('username')
        }).then((res) => {
            if(res.data['message'] === "Error") {
                return Swal.fire({
                    icon: 'error',
                    title: 'Ocorreu um erro'
                })
            } else {
                return Swal.fire({
                    icon: 'success',
                    title: 'Wiki Criada com sucesso!'
                })
            }
        })
    } else {
        return Swal.fire('Produção cancelada', '', 'error')
    }
    })
}

if(localStorage.getItem("mode") === "dark") {
    document.querySelector('body').setAttribute("class", "dark-mode")
}