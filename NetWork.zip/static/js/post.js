$(document).ready(function() {
	// const instance = axios.create({
 //  		baseURL: 'https://api.example.com'
	// });
    var titulo = document.querySelector('h2').textContent

    var authorPost = document.querySelector("#author-post").textContent
    if(authorPost === localStorage.getItem("username")) {
    	document.querySelector(".footerin").innerHTML += `
    		<div class="edit-p">
		<h3>Editar Post</h3>
		<button class="btn-e">Editar Post</button>
	</div>
	<div class="delete">
		<h3>Excluir artigo</h3>
		<button key='{{ title }}' value="curtir" id="deleteArtigo" class="btn-i">Excluir</button>
	</div>
    	`
    }

    var conteudo = document.querySelector('#conteudo').textContent
    var converter = new showdown.Converter(),
    text      = conteudo.replace('\n', '').replace('\t', ''),
    html      = converter.makeHtml(text);
    console.log(html)
    document.querySelector('#conteudo').innerHTML = html.replace('<pre>', '')

	$('#new-comment-text').keyup(function(e) {
                if(e.keyCode == 13) {
                    $(this).trigger("enterKey");
                }
            });
	$('#new-comment-text').on("enterKey", function(e){
		var post = $(this).attr("key")
        console.log($('#new-comment-text').val())
        axios.post("/api/v1/create/comment", {
        	"post": post,
        	"author": localStorage.getItem('username'),
        	"content": $('#new-comment-text').val()
        }).then((res) => {
        	console.log(res.data)
        	if(res.data['message'] === "Comentário Adicionado!") {
        		Swal.fire({
				  position: 'top-end',
				  icon: 'success',
				  title: 'Comentário adicionado com sucesso!',
				  showConfirmButton: false,
				  timer: 1500
				})
        	} else {
        		Swal.fire({
        			icon: 'error',
        			title: 'Ocorreu um erro'
        		})
        	}
        })
     });

	$('#likei').click(function() {
		if(document.querySelector(".btn-i").textContent === "Descurtir") {
			document.querySelector(".btn-i").style.backgroundColor = "#ff0000"
			document.querySelector(".btn-i").textContent = "Curtir"
			return Swal.fire({
				position: 'top-end',
				icon: 'error',
				title: "Publicação descurtida com sucesso!",
				showConfirmButton: false,
				timer: 1500
			})
		}
		console.log('ok')
		var post = $(this).attr('key')
		axios.post('/api/v1/add/like', {
			"post": post,
			"author": localStorage.getItem('username')
		}).then((res) => {
			if(res.data['message'] === 'Like!') {
				Swal.fire({
				  position: 'top-end',
				  icon: 'success',
				  title: 'Publicação curtida com sucesso!',
				  showConfirmButton: false,
				  timer: 1500
				})
				document.querySelector(".btn-i").style.backgroundColor = '#0000'
				document.querySelector(".btn-i").style.borderColor = "#FF0000"
				if(document.querySelector(".btn-i").textContent === "Curtir") {
					document.querySelector(".btn-i").textContent = "Descurtir"
				} else {
					document.querySelector(".btn-i").textContent = "Curtir"
				}
			} else {
				return Swal.fire({
					icon: 'error',
					title: "Houve um erro"
				})
			}
		})
	})

	$(".btn-e").click(function() {
		var button = document.querySelector(".btn-e")
		if(document.querySelector('.btn-e').textContent === "Save") {
			axios.post("/api/v1/edit/post", {
				"post": document.querySelector("h2").textContent,
				"body": document.querySelector("#conteudo").textContent,
				"title": titulo
			}).then((r) => {
				let data = r.data
				if(data["message"] === "success") {
					button.textContent = "Editar Post"
					button.style.backgroundColor = "#0000FF"
					document.querySelector('h2').removeAttribute("contenteditable")
					document.querySelector("#conteudo").removeAttribute("contenteditable")
					return Swal.fire({
						position: 'top-end',
						icon: 'success',
						title: "Publicação editada com sucesso!",
						showConfirmButton: false,
						timer: 1500
					})

				} else {
					button.textContent = "Editar Post"
					button.style.backgroundColor = "#0000FF"
					document.querySelector('h2').removeAttribute("contenteditable")
					document.querySelector("#conteudo").removeAttribute("contenteditable")
					return Swal.fire({
						position: 'top-end',
						icon: 'error',
						title: "Erro ao salvar alterações",
						showConfirmButton: false,
						timer: 1500
					})
				}
			})
		}
		document.querySelector('h2').setAttribute("contenteditable", "")
		document.querySelector("#conteudo").setAttribute("contenteditable", "")
		button.textContent = "Save"
		button.style.backgroundColor = "green"
	})

	var commentsDiv = document.querySelector('.commentsi')
	axios.get(`/post/comments?post=${titulo.replace(" ","-")}`).then((res) => {
		var comentarios = res.data['comments']
		comentarios.forEach(function(item) {
			var divzin = `
				<div class="comment">
					<p><strong>@${item["author"]}</strong></p>
					<p>${item['content']}</p>
				</div>
			`

			commentsDiv.innerHTML += divzin
		})
	})

	$('#deleteArtigo').click(function() {
		axios.post("/api/v1/delete/post", {
			"post": titulo
		}).then((r) => {
			if(r.data["message"] === "success") {
				Swal.fire({
					icon: 'error',
					title: "Publicação excluída com sucesso!",
					position: 'top-end',
					timer: 1500
				})
				return window.location.href = "/home"
			} else {
				return Swal.fire({
					icon: 'error',
					title: "Erro ao deletar Artigo"
				})
			}
		})
	})

	axios.get('/api/v1/get/likes?post=O-que-é-JavaScript').then((res) => {
		var likes = res.data["likes"]
		// let likesDiv = document.querySelector('.likeszin')
		// likesDiv.innerText = likes
	})

	if(localStorage.getItem("mode") === "dark") {
    document.querySelector('body').setAttribute("class", "dark-mode")
}
})