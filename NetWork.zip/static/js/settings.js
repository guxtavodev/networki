const api = axios.create({
  baseURL: 'http://127.0.0.1:2019/api/v1'
});

function getInfos() {
	api.get(`/user?username=${localStorage.getItem('username')}`).then((res) => {
		console.log(res.data)
		// Colocando os valores nos inputs
		$('#username').val(res.data['message']['username'])
		$('#email').val(res.data['message']['email'])
		$('#telephone').val(res.data['message']['telephone'])
		$('#password').val(res.data['message']['password'])
		$('#appit')
	})
}

getInfos()

function enviarAlteracao() {
	api.post(`/edit/user`, {
		"usernameLast": localStorage.getItem('id'),
		"username": $('#username').val(),
		"email": $('#email').val(),
		"telephone": $('#telephone').val(),
		"password": $('#password').val(),
		"link": $('#appit').val().substr(24),
		"bio": $("#bio").val()
	}).then((res) => {
		console.log(res)
		if(res.data['message'] === "OK") {
			Swal.fire({
			  position: 'top-end',
			  icon: 'success',
			  title: 'Alterações salvas com sucesso!',
			  showConfirmButton: false,
			  timer: 1500
			})
		} else {
			Swal.fire({
				icon: 'error',
				title: 'Houve um erro'
			})
		}
	})
}

document.querySelector('#dark-light').addEventListener('change', function() {
	var valor = $('#dark-light').val()
	console.log(valor)
	if(valor === "dark") {
		localStorage.setItem("mode", "dark")
	} else {
		localStorage.setItem("mode", "light")
	}
})

if(localStorage.getItem("mode") === "dark") {
    document.querySelector('body').setAttribute("class", "dark-mode")
}

function Sair() {
	localStorage.removeItem("username")
	window.location.href = '/entrar'
}
