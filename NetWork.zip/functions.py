import random
import sqlite3 as sql

def geradorDeID():
	lista = []
	for i in range(15):
		x = random.randint(1, 9)
		lista.append(x)

	return "".join(map(str, lista))

def getArtigo(nome):
	# Checar se esse artigo existe
	db = sql.connect("dados.db")
	cursor = db.cursor()
	r = cursor.execute("SELECT title, conteudo, author, comments FROM posts WHERE title = ?", (nome,))
	fetc = r.fetchall()
	db.close()
	dados = {}
	# print(fetc)
	if fetc != None:
		dados['title'] = fetc[0][0]
		dados['conteudo'] = fetc[0][1]
		dados['author'] = fetc[0][2]
		return dados
	else:
		return "Artigo não existe"

def ArtigosHome():
	lista = []

	# Pegar todos os artigos que existe
	db = sql.connect("dados.db")
	cursor = db.cursor()
	r = cursor.execute("SELECT title, conteudo, author FROM posts")
	fetc = r.fetchall()
	db.close()

	count = 0
	for item in fetc:
		print(item[1])
		lista.append({
			"title": item[0],
			"conteudo": item[1],
			"author": item[2]
		})

		count=+1

	posts = []
	for i in range(5):
		it = random.choice(lista)
		posts.append(it)

	return posts

def Comentarios(post):
	print(post)
	db = sql.connect('dados.db')
	cur = db.cursor()
	r = cur.execute("""
		SELECT comments FROM posts WHERE title = ?
		""", (post, ))
	fet = r.fetchall()
	db.close()

	print(fet[0][0])

	comentarios = fet[0][0].split("&")
	comments = []
	for comentario in comentarios:
		dado = comentario.split(":")
		comments.append({
			"author": dado[0],
			"content": dado[1]
		})

	return comments

Comentarios("Como criar um post no NetWork+")

def getUser(username):
	db = sql.connect('dados.db')
	cur = db.cursor()
	r = cur.execute("""
		SELECT username, email, telephone, links, likes, password, bio FROM users WHERE username = ?
	""", (username,))
	dados = r.fetchall()
	db.close()

	userinfo = {
		"username": dados[0][0],
		"email": dados[0][1] or "",
		"telephone": dados[0][2] or "",
		"links": dados[0][3] or "",
		"likes": dados[0][4] or "",
		"password": dados[0][5],
		"bio": dados[0][6] or ""
	}

	# print(dados[0][0])
	# print(userinfo)
	return userinfo

def getUserByID(id):
	db = sql.connect('dados.db')
	cur = db.cursor()
	r = cur.execute("""
		SELECT username, email, telephone, links, likes, password, bio FROM users WHERE id = ?
	""", (id,))
	dados = r.fetchall()
	db.close()

	userinfo = {
		"username": dados[0][0],
		"email": dados[0][1] or "",
		"telephone": dados[0][2] or "",
		"links": dados[0][3] or "",
		"likes": dados[0][4] or "",
		"password": dados[0][5],
		"bio": dados[0][6] or ""
	}

	# print(dados[0][0])
	# print(userinfo)
	return userinfo

getUser('guxtavodev')

db = sql.connect('dados.db')
cur = db.cursor()
r = cur.execute("""
		SELECT likes FROM users WHERE username = 'guxtavodev'
""")
res = r.fetchone()[0]
db.commit()
db.close()
# print(res)

# db = sql.connect('dados.db')
# cur = db.cursor()
# r = cur.execute("""
# 		UPDATE users 
# 		SET likes = ?
# 		WHERE username = 'guxtavodev'
# """, ('1'))
# db.commit()
# db.close()
# print(int(res)+1)

db = sql.connect('dados.db')
cur = db.cursor()
r = cur.execute("SELECT * FROM posts WHERE author = ?", ('guxtavodev',))
rer = r.fetchall()
db.close()

#print(rer)

postsUser = []
for post in rer:
	posts = {}
	posts['title'] = post[0]
	posts['conteudo'] = post[1]
	postsUser.append(f"""
		<a href="http://127.0.0.1/post/{posts['title'].replace(" ", "-")}">
			<div class="post">
				<p><strong>{posts['title']}</strong></p>
				<p>{posts['conteudo']}</p>
			</div>
		</a>
		""".replace("\t", "").replace("\n",""))

# print("".join(map(str, postsUser)))

db = sql.connect('dados.db')
cur = db.cursor()

r = cur.execute('SELECT * FROM wikis WHERE author = ?', ('guxtavodev',))
result = r.fetchall()
db.commit()
db.close()

